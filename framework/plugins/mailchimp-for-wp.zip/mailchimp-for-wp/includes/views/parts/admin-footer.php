<?php 
if( ! defined("MC4WP_LITE_VERSION") ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit;
}
?>
<br style="clear:both;" />
<p class="help">Enjoying this plugin? <a href="http://dannyvankooten.com/mailchimp-for-wordpress/#utm_source=lite-plugin&utm_medium=link&utm_campaign=footer-link">Upgrade to MailChimp for WordPress Pro now</a> for an even better plugin, you will love it.</p>
<p class="help">Submit your feature requests or vote for new features <a href="http://www.google.com/moderator/#15/e=20c6b7&t=20c6b7.40">here</a>.</p>
<p class="help"><?php _e( 'This plugin is not developed by or affiliated with MailChimp in any way.', 'mailchimp-for-wp' ); ?></p>